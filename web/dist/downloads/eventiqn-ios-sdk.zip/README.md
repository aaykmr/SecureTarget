# EventIQN iOS SDK v0.1.0

## Install

1. Unzip and drag the `EventIQNSDK` folder into your Xcode project (copy items if needed).
2. Or add the folder as a local Swift package: File → Add Package Dependencies → Add Local…

## Configure

```swift
import EventIQNSDK

let sdk = EventIQNSDK(config: EventIQNConfig(
  apiKey: "YOUR_API_KEY",
  companyId: "YOUR_COMPANY_ID",
  endpoint: URL(string: "https://your-ingest-host.example.com")!
))

Task {
  try await sdk.bootstrapSession()
}
```

## Docs

See your EventIQN dashboard → Integration → iOS for deep links, install attribution, and conversions.
