# EventIQN Android SDK v0.1.0

## Install

1. Unzip and copy `src/main/java/com/eventiqn/sdk/*.kt` into your app module (same package path).
2. Add the Play Install Referrer library to `app/build.gradle`:

```gradle
dependencies {
  implementation "com.android.installreferrer:installreferrer:2.2"
}
```

## Configure

```kotlin
val sdk = EventIQNSdk(
  applicationContext,
  EventIQNConfig(
    apiKey = "YOUR_API_KEY",
    companyId = "YOUR_COMPANY_ID",
    endpoint = "https://your-ingest-host.example.com"
  )
)

sdk.ensureSession { error ->
  if (error != null) Log.e("EventIQN", "bootstrap failed", error)
}
```

## Docs

See your EventIQN dashboard → Integration → Android for deep links, Play Store attribution, and conversions.
